
<11/16/00>
================================================================
Model Name              : Spacemarine40k
installation directory  : /baseq3/players/spacemarine40k
Author                  : Chris Glenn
Skin Authors 		: Chris Glenn - Ultramarines, Blood Angels, Crimson Fists, Dark Angels
                        : Jeremy Bone - Legion of the Damned
Email Address           : alexin@cglenn.com



Model description       : The Space Marines - Created in the distant past through genetic manipulation and arcane science, Space Marines are Humanity's ultimate warriors, dedicated to the defense of the Emperor and the Imperium of Man. A Space Marine army is a compact force of elite warriors each one the equivalent of ten normal men. From the steadfast reliablity of a Space Marine Tactical Squad to the alien-blasting power of the Predator Annihilator Tank, a Space Marine Army is flexible enough to defeat any opponent.

More info about Warhammer 40,000 and Space Marines: 
http://www.games-workshop.com/Warhammer40k/40kforces/Space_Marines.html
http://www.games-workshop.com/Warhammer40k/40kintro.html



Other info              : This is my first effort creating Quake 3 Arena players models, and I think it turned out ok. I learned a lot making it and I hope to take that knowledge and make some seriously cool models. One area I had some trouble with was the skinmapping. The mapping itself wasn't bad but the skin layout could have used some more work. 
	Another trouble area was the animations. Between lack of experience and fighting with biped (I'm not sure if I can get used to no control curves) the animations we're a little difficult. I learned A LOT in doing these animations. Anyway, this is one area I want to improve on. Basically, I could have redone the animations over and over and they would have been better each time, but I didn't want to work on the same model over and over again. I figured I would release the model as it is and do the next model better. 



Credits                 : I used one of Paul Steed's bip files (Keel's I think) as reference for a couple of the animations. The crouch walk in particular was tricky. I didn't copy ANY keys however. 
			: I used Doom's Bot as the Space Marine's bot. I changed almost nothing about the bot except for all of the chat lines. I gathered a bunch of wh40k quotes and verbage for the chat lines. 
			: Goatman, for showing me the ropes with Q3 specific tools. 
			: Mattsterio, for letting us play with his recording equipment for the sounds.

Additional Credits to   : id Software, Games Workshop
			: www.polycount.com - Without this site this model would never have been created. The polycount crew is Bad Ass. And mad props to the message board members, who kept me motivated to finish this.

Thanks to               : Neversoft Entertainment, Skillzilla, Mattsterio, and special thanks to Sarah. 
================================================================
* Play Information *

New Sounds              : YES
CTF Skins               : YES
LODs			: YES
BOT Support             : YES

* Construction *
Poly Count              : 1202 polys
Vert Count              : 640 Verts
Skin Count              : 5 DM, 2 CTF
Base                    : new
Editor used             : 3dsmax3.1, Character Studio 2.2, Photoshop 5.5
Build/Animation time    : 3 months on and off


* How to install this model *

 Copy the spacemarine40k.pk3 into your /Quake III Arena/baseq3/ directory.

* Copyright / Permissions *

This model may be freely distributed, provided all contents remain UNALTERED and my credit is maintaned. 

QUAKE III Arena(R) and QUAKE II(R) and QUAKE(R) are registered trademarks of id Software, Inc.
SPACE MARINES(R), ULTRAMARINES(R), BLOODANGELS(R), CRIMSONFISTS(R), LEGIONoftheDAMNED(R), DARK ANGELS(R), WARHAMMER40,000(R) are � Copyright Games Workshop Limited 2000. All rights reserved. 

